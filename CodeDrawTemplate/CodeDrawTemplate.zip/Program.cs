﻿using CodeDrawNS;
using System.Drawing;

namespace $safeprojectname$
{
	class Program
	{
		static void Main(string[] args)
		{
			CodeDraw cd = new CodeDraw();

			cd.DrawText(100, 100, "Hello World!");

			cd.Color = Color.Red;
			cd.FillCircle(200, 200, 50);
			cd.FillCircle(300, 200, 50);

			cd.FillPolygon((160, 230), (250, 190), (340, 230), (250, 330));

			cd.Show();
		}
	}
}
